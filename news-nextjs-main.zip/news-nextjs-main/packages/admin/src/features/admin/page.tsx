import AdminDashboard from "../../features/admin/AdminDashboard";
export default function Page() {
  return <AdminDashboard />;
}
