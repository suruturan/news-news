import ManageUsers from "../../../features/admin/ManageUsers";
export default function Page() {
  return <ManageUsers />;
}
