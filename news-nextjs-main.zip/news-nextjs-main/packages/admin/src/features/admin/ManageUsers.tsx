export default function ManageUsers() {
  return (
    <div style={{ padding: 30 }}>
      <h1>Пользователи (в разработке)</h1>
    </div>
  );
}
