# 📱 News Platform — Mobile (React Native)

Это мобильное приложение новостной платформы.  
Оно запускается на Android (эмулятор или физический телефон).

Документ написан так, чтобы запустить приложение смог человек, который никогда не работал с React Native.

# ⚙️ 1. Что нужно установить

## ✔ Node.js  
Скачать: https://nodejs.org/

## ✔ pnpm  
Установка:
npm install -g pnpm

✔ Android Studio
Скачать: https://developer.android.com/studio

В Android Studio: Открыть SDK Manager

Убедиться, что установлены:
- Android SDK
- Platform Tools
- Build-tools
- Открыть Device Manager
- Создать виртуальный телефон (например, Pixel 5 → Android 13)

# 📦 2. Установка зависимостей
Перейдите в мобильную папку:
cd packages/mobile

Установите зависимости:
pnpm install

# ▶ 3. Запуск Metro Bundler
Metro — это сервер, который собирает мобильное приложение.

Запустите:
pnpm start
Появится окно Metro.

# ▶ 4. Запуск приложения на Android
Есть два варианта:

📌 Вариант 1 — через Metro Bundler
В терминале нажмите:

a — открыть Android-эмулятор

📌 Вариант 2 — вручную
Убедитесь, что устройство отображается:
adb devices

Запустите:
pnpm run android
После этого приложение автоматически откроется на телефоне.

# 🧪 5. Проверка работоспособности
- Приложение открывается на эмуляторе
- Показывает список новостей
- Работают экраны и навигация
- Заглушки (mock news) отображаются без интернета

# 🗂 Структура проекта
mobile/
├── app/              # Экраны и навигация
├── shared/           # Общие модули (UI, hooks)
├── features/         # Фичи (список новостей, карточки)
├── package.json
└── README.md

# ❗ Возможные ошибки и их решения
Ошибка: "SDK not found"
Значит Android SDK не установлен или не прописан путь.

Добавьте системную переменную:
ANDROID_HOME=C:\Users\Имя\AppData\Local\Android\Sdk

Ошибка: "Emulator not found"
Запустите AVD вручную через Android Studio → Device Manager.

Ошибка: "Cannot connect to Metro"
Попробуйте запустить Metro отдельно:
pnpm start --reset-cache

# 🎉 Готово!
Теперь мобильное приложение полностью готово к запуску и разработке.
